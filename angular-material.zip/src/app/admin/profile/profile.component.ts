import { Component, OnInit } from '@angular/core';
import { TokenStorageService } from '../../_services/token-storage.service';
import { MatDialogRef } from '@angular/material';
import {UserService} from '../../_services/user.service'
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  currentUser: any;
  isLoggedIn = false;
  roles:string[];
  groups:string[];
  permissions:string[];
  username: string;
  firstName: String;
  lastName: String;
  email: string;
  constructor(private token: TokenStorageService,private userService: UserService,private  dialogRef: MatDialogRef<any>) { }

  ngOnInit() {
     this.currentUser = this.token.getUser();
    //  console.log(this.currentUser.user)
    this.isLoggedIn = !!this.token.getToken();
    // if (this.router.url.includes("/login")) {
    //   this.isLoginShow = false
    // }
    if (this.isLoggedIn) {
      this.userService.getUserInfo().subscribe(
        data => {
          console.log(JSON.stringify(data))
         // this.userDetails = JSON.stringify(data);
         this.username=data.login;
          this.firstName = data.first_name;
          this.lastName = data.last_name;
          this.email = data.email;
          this.roles=data.roles;
          this.groups=data.groups;
          this.permissions=data.permissions;
         
        })
       
  }
  }
  onClose(){
    this.dialogRef.close()
  }
 
}
