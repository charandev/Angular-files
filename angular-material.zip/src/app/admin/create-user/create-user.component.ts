import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { UserService } from '../../_services/user.service';
import { FormBuilder, FormGroup, Validators, FormControl, AbstractControl } from '@angular/forms';
import { NotificationService } from '../../_services/notification.service';
@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.css']
})
export class CreateUserComponent implements OnInit {
  form: FormGroup;
  hide:any
  hide_cfm:any
  constructor(public service: UserService, private ref: MatDialogRef<any>, private notifications: NotificationService, private fb: FormBuilder) { }
  message: string
  ngOnInit() {
    this.form = this.fb.group({
      $key: [''],
      login: ['', [
        Validators.required,
        Validators.minLength(5),
        Validators.pattern("^[a-zA-Z][a-zA-Z0-9\.\_]{3,18}[a-zA-Z0-9]$"),
        Validators.maxLength(20)]
      ],
      first_name: ['', [
        Validators.required,
        Validators.minLength(2),
        Validators.maxLength(50),
        Validators.pattern("^[a-zA-Z][a-zA-Z0-9 \-']{0,48}[a-zA-Z0-9]$")]
      ],
      last_name: ['', [
        Validators.required,
        Validators.minLength(2),
        Validators.maxLength(50),
        Validators.pattern("^[a-zA-Z][a-zA-Z0-9 \-']{0,48}[a-zA-Z0-9]$")]
      ],
      email: ['', [
        Validators.required,
        Validators.email]
      ],
      password: ['', [
        Validators.required,
        Validators.minLength(6),
        Validators.maxLength(12),
        Validators.pattern(
          /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%*()_+])/
        )]
      ],

      cfm_password: ['', [Validators.required,
        Validators.minLength(6),
        Validators.maxLength(12),
      Validators.pattern(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%*()_+])/
      )
      ]]

    }, { validator: this.passwordMatchValidator });

  }
  passwordMatchValidator(c: AbstractControl) {
    if (c.get('password').value !== c.get('cfm_password').value) {
      c.get('cfm_password').setErrors({ invalid: true })
    }
  }

  onClose() {
    this.ref.close()
  }
  onClear(event) {
    this.form.reset();
    event.preventDefault()
  }

  createUser(event) {
    event.preventDefault()
    this.service.createNewUser(this.form).subscribe(
      data => {
        this.message = "User Added Successfully"
        this.notifications.success(this.message)
        this.ref.close();
        setTimeout(() => {
          window.location.reload()
        }, 3000)

      }, error => {
        this.message = "Failed to add user. Error Occured " + error.error
        this.notifications.warn(this.message)
        // console.log(error);

      }
    )
  }
  onKeydown(event) {
    if (event.keyCode === 32) {
      return false;
    }
  }

  get f() {
    return this.form.controls;
  }


}
