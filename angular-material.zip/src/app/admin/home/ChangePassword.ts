export class ChangePassword{
    login:string
    new_password:string
}