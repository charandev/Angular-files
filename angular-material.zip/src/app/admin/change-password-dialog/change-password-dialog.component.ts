import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AbstractControl, FormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { UserService } from 'src/app/_services/user.service';
import { NotificationService } from 'src/app/_services/notification.service';
@Component({
  selector: 'app-change-password-dialog',
  templateUrl: './change-password-dialog.component.html',
  styleUrls: ['./change-password-dialog.component.css']
})
export class ChangePasswordDialogComponent implements OnInit {
  login: string
  form: FormGroup
  hide:any
  hide_cfm:any
  constructor(private fb: FormBuilder, public dialogRef: MatDialogRef<ChangePasswordDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private service: UserService, private notif: NotificationService) { }

  ngOnInit() {
    this.login = this.data.login
    this.form = this.fb.group({
      username: [{ value: this.login, disabled: true }],

      password: ['', [Validators.required,
      Validators.minLength(6),
      Validators.maxLength(12),
      Validators.pattern(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%*()_+])/
      )

      ]],
      cfm_password: ['', [Validators.required,
      Validators.minLength(5),
      Validators.maxLength(12),
      Validators.pattern(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%*()_+])/
      )
      ]]

    }, { validator: this.passwordMatchValidator });

  }

  passwordMatchValidator(c: AbstractControl) {
    if (c.get('password').value !== c.get('cfm_password').value) {
      c.get('cfm_password').setErrors({ invalid: true })
    }
  }
  get f() {
    return this.form.controls;
  }
  onClose() {
    this.dialogRef.close()
  }
  changePassword(event) {
    event.preventDefault()
    this.service.changePassword(this.login, this.form.get('password').value).subscribe(
      data => {
        this.notif.success(data.message)
        setTimeout(() => {
          window.location.reload()
        }, 2000)
      }, error => {
        this.notif.warn(error.message)
        console.log(error.message);

      }
    )
  }

  onKeydown(event) {
    if (event.keyCode === 32) {
      return false;
    }


  }
}
