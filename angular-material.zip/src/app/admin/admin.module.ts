import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { HomeComponent } from './home/home.component';
import { MaterialModule } from '../material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { ChangePasswordDialogComponent } from './change-password-dialog/change-password-dialog.component';
import { ProfileComponent } from './profile/profile.component';
import { ChangePasswordDialogComponent } from './change-password-dialog/change-password-dialog.component';
import { CreateUserComponent } from './create-user/create-user.component';
import { EditUserDialogComponent } from './edit-user-dialog/edit-user-dialog.component';
import { UserAccessDialogComponent } from './user-access-dialog/user-access-dialog.component';


@NgModule({
  declarations: [HomeComponent, CreateUserComponent, ProfileComponent, ChangePasswordDialogComponent, EditUserDialogComponent, UserAccessDialogComponent],
  imports: [
    CommonModule,
    AdminRoutingModule,
    MaterialModule,
    FormsModule, 
    ReactiveFormsModule
  ],
  entryComponents: [CreateUserComponent, ProfileComponent, ChangePasswordDialogComponent, EditUserDialogComponent, UserAccessDialogComponent]

})
export class AdminModule { }
