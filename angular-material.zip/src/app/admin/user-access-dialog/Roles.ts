export class Roles{
    set:string[];
    unset:string[];
    constructor(set:string[],unset:string[]){
        this.set=set;
        this.unset=unset;
    }
}

    