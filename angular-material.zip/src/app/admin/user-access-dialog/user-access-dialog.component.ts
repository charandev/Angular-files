import { Component, OnInit,Inject } from '@angular/core';
import {UserService} from '../../_services/user.service';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import {FormBuilder, FormControl, FormGroup} from '@angular/forms';
import{UserAccessDetails} from './UserAccessDetails'
import { Roles } from './Roles';
import { Groups } from './Groups';
import { Permissions } from './Permissions';
import swal from 'sweetalert2';
@Component({
  selector: 'app-user-access-dialog',
  templateUrl: './user-access-dialog.component.html',
  styleUrls: ['./user-access-dialog.component.css']
})
export class UserAccessDialogComponent implements OnInit {

  private userAccessDetails: UserAccessDetails;
  private userRole:Roles;
  private userGroup:Groups;
  private userPermission:Permissions;
groups:string[];
roles:string[];
permissions:string[];
user :string;
login:string
options: FormGroup;
unsetRolesControl = new FormControl(true);
floatLabelControl = new FormControl('auto');
unsetGroups=new FormControl(true);
unsetPermissions=new FormControl(true);
setrole=new FormControl('');
setgroup=new FormControl('');
setpermission=new FormControl('');
groupset = new Set();
roleset=new Set();
permissionset=new Set();
  constructor(private userService: UserService,private userAccessService:UserService,fb: FormBuilder,  public dialogRef: MatDialogRef<UserAccessDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public userdata: any) { 
      this.options = fb.group({
        
        hideRequired: this.unsetRolesControl,
        floatLabel: this.floatLabelControl,
       

      });
    }

  ngOnInit() {
    this.login=this.userdata.login;
    // console.log("userName:"+this.login)
    this.userService.getUserdetails(this.login).subscribe(data =>{
    this.roles=data.roles;
    this.permissions=data.permissions;
    this.groups=data.groups;
    })

  }
  selected_checkbox:string[];
  unsetValue:any;
  unsetgrp:string;
  unsetpermission:any;
  unsetrole:any;


  /*

  This is usser Access Method
  */
userAccess(){
 this.gset.forEach(childObj=> {
  // console.log(childObj);
  this.unsetgrp=childObj;
  });
  // if(this.setrole.value){
  // this.userRole=new Roles(this.setrole.value.split(','),this.unsetValue);
  // }
if(this.setgroup.value||this.unsetgrp){
 
  if(this.setgroup.value && this.unsetgrp){
    this.userGroup=new Groups(this.setgroup.value.split(','),this.unsetgrp.split(','));
  }
else {
  if(this.setgroup.value){
    this.userGroup=new Groups(this.setgroup.value.split(','),this.unsetValue);
  }
  else{
    this.userGroup=new Groups(this.unsetValue,this.unsetgrp.split(','));
  }
}

}

this.roleset.forEach(childObj=> {
  console.log(childObj);
  this.unsetrole=childObj;
  });
 
if(this.setrole.value||this.unsetrole){
  console.log("unset grp");
  if(this.setrole.value && this.unsetrole){
    this.userRole=new Roles(this.setrole.value.split(','),this.unsetrole.split(','));
   // this.userGroup=new Groups(this.setgroup.value.split(','),this.unsetgrp.split(''));
  }
else {
  if(this.setrole.value){
    this.userRole=new Roles(this.setrole.value.split(','),this.unsetValue);
  }
  else{
    this.userRole=new Roles(this.unsetValue,this.unsetrole.split(','));
  }
}
}
this.permissionset.forEach(childObj=> {
  console.log(childObj);
  this.unsetpermission=childObj;
  });
if(this.setpermission.value||this.unsetpermission){
  
  console.log("inside permission");
  if(this.setpermission.value && this.unsetpermission){
this.userPermission=new Permissions(this.setpermission.value.split(',')
,this.unsetpermission.split(','));

}
else {
  if(this.setpermission.value){
    this.userPermission=new Permissions(this.setpermission.value.split(','),this.unsetValue);
  }
  else{
    this.userPermission=new Permissions(this.unsetValue,this.unsetpermission.split(','));
  }
}
}
console.log("form field:"+this.permissionset);
console.log("form field:"+this.setpermission.value);
  this.userAccessDetails=new UserAccessDetails(this.login,this.userRole,this.userGroup,this.userPermission);
  this.userAccessService.updateUserAccess(this.userAccessDetails).subscribe(
    data=>{
      console.log(data.message+" "+data.errorMessage);
      (swal as any).fire(data.message);
      this.onNoClick()
  });
}
 gset=new Set<string>();
checkgrp(event){
  if(!event.checked){
  this.gset.add(event.source.id);
}
if(event.checked){
this.gset.delete(event.source.id);
}
}
checkrole(event){
  if(!event.checked){
    this.roleset.add(event.source.id);
  }
  if(event.checked){
   
  this.roleset.delete(event.source.id);
  }
}
checkpermission(event){
  if(!event.checked){
    this.permissionset.add(event.source.id);
  }
  if(event.checked){
    console.log("inside grp")
  this.permissionset.delete(event.source.id);
  }
 
}

onNoClick(): void {
  this.dialogRef.close();
  }
 
}
