import { Permissions } from "./Permissions";
import { Roles } from "./Roles";
import { Groups } from "./Groups";

export class UserAccessDetails {
    
        login: String;
        roles:Roles;
        permissions:Permissions;
        groups:Groups;
       
        constructor(login:string,roles:Roles,groups:Groups,permissions:Permissions){
            this.login=login;
            this.roles=roles;
            this.groups=groups;
            this.permissions=permissions;

        }
        
    }

