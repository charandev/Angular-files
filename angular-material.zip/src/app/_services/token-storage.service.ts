import { Injectable } from '@angular/core';

const TOKEN_KEY = 'auth-user';

@Injectable({
  providedIn: 'root'
})
export class TokenStorageService {

  constructor() { }


signOut() {
  window.sessionStorage.clear();
}

public saveToken(token: string) {
  window.sessionStorage.removeItem(TOKEN_KEY);
  // console.log(token);
  
  window.sessionStorage.setItem(TOKEN_KEY, token);
}

public getToken(): string {
      
  return JSON.parse(sessionStorage.getItem(TOKEN_KEY));
}

public saveUserToken(user) {
  window.sessionStorage.removeItem(TOKEN_KEY);
  window.sessionStorage.setItem(TOKEN_KEY, JSON.stringify(user.token));
}

public getUser() {
  return JSON.parse(sessionStorage.getItem(TOKEN_KEY));
}
}