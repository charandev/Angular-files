import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Template } from '../admin/create-user/Template';
import { ChangePassword } from '../admin/home/ChangePassword';
import { EditUser } from '../admin/edit-user-dialog/EditUser';
import { ApiSettings } from './ApiSettings';

// const API_URL= 'https://localhost';
// const API_URL = 'https://amsmlpipe3.mindtree.com';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }
  
  getUserList(): Observable<any> {
    return this.http.get(ApiSettings.API_BASE_URL + "/intelyzers/users")
  }
  getUserInfo(): Observable<any> {
    return this.http.get(ApiSettings.API_BASE_URL + "/intelyzers/user")
  }
  createNewUser(form: FormGroup): Observable<any> {
    var t = new Template();
    t.login = form.get("login").value
    t.first_name = form.get("first_name").value
    t.last_name = form.get("last_name").value
    t.email = form.get("email").value
    t.password = form.get("password").value
    // t : form 
    // console.log(t);
    return this.http.post(ApiSettings.API_BASE_URL + "/intelyzers/user", t)
  }
  deleteUser(login: string): Observable<any> {
    return this.http.delete(ApiSettings.API_BASE_URL + "/intelyzers/user/" + login);
  }
  changePassword(login: string, password: string): Observable<any> {
    var t = new ChangePassword
    t.login = login
    t.new_password = password
    // console.log(t);

    return this.http.post(ApiSettings.API_BASE_URL + "/intelyzers/user/resetPassword", t)
  }

  editUser(form: FormGroup): Observable<any> {
    var dataToSend = new EditUser();
    dataToSend.login = form.get('username').value;
    dataToSend.first_name = form.get('first_name').value;
    dataToSend.last_name = form.get('last_name').value
    dataToSend.email = form.get('email').value
    return this.http.post(ApiSettings.API_BASE_URL+"/intelyzers/user/update",dataToSend);
  }

  getUserdetails(user:String): Observable<any> {
    return this.http.get(ApiSettings.API_BASE_URL + "/intelyzers/user/"+user)
  }

  updateUserAccess(value): Observable<any>{
    console.log(JSON.stringify(value))
    return this.http.post(ApiSettings.API_BASE_URL+"/intelyzers/user/access",value)

  }
  predictionLogQuery(value):Observable<any>{
    // console.log("in service"+JSON.stringify(value));
    return this.http.post(ApiSettings.API_BASE_URL+"/intelyzers/prediction-log/query",value);
  }
}
