import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ApiSettings } from './ApiSettings';

// const AUTH_API='https://localhost';
//  const AUTH_API = 'https://amsmlpipe3.mindtree.com/intelyzers/login';

// let authorizationData = 'Basic ' + btoa('intelyzer.admin:intelyzeradmin123');
// let authorizationPredData = 'Basic ' + btoa('atlastest:ATLAStest12345');

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient) { }

  login(username,password): Observable<any> {
    const headerOptions = {
      headers: new HttpHeaders({
          'Content-Type':  'application/json',
          'Authorization': 'Basic ' + btoa(username+':'+password)
      })
    }
    return this.http.get(ApiSettings.API_BASE_URL+"/intelyzers/login",  headerOptions )
  };
  loginPredUser(username,password): Observable<any> {
    const headerOptions = {
      headers: new HttpHeaders({
          'Content-Type':  'application/json',
          'Authorization': 'Basic ' + btoa(username+':'+password)
      })
    }
    return this.http.get(ApiSettings.API_BASE_URL+"/intelyzers/login",  headerOptions )
  };
}
