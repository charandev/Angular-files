const parsedUrl = new URL(window.location.href);
const baseUrl = parsedUrl.origin.split(/:[0-9]/)[0];

export class ApiSettings {
    public static API_BASE_URL =baseUrl; 
    //make sure this value set to "baseUrl" for deployement, 
    //otherwise the deployement will not work.
}