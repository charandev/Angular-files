import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedRoutingModule } from './shared-routing.module';
import { HeaderComponent } from './header/header.component';
import { MaterialModule } from '../material.module';
import { LoginComponent } from './login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FooterComponent } from './footer/footer.component';
import { ChangePasswordDialogComponent } from '../admin/change-password-dialog/change-password-dialog.component';
import { ProfileComponent } from '../admin/profile/profile.component';

@NgModule({
  declarations: [FooterComponent, HeaderComponent, LoginComponent],
  imports: [
    CommonModule,
    SharedRoutingModule,
    MaterialModule,
    FormsModule, ReactiveFormsModule
  ], exports: [HeaderComponent, FooterComponent, LoginComponent],
})
export class SharedModule { }
