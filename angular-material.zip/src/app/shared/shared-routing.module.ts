import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService } from '../_services/auth-guard.service';
import { LoginComponent } from './login/login.component';
import { PredictionLogsQueryComponent } from '../intelyzers/prediction-logs-query/prediction-logs-query.component';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('../admin/admin.module').then(m => m.AdminModule),
    // loadChildren: '../admin/admin.module#AdminModule',
    canActivate: [AuthGuardService]
  },
  {
    path: 'intelyzers',
    loadChildren: () => import('../intelyzers/intelyzers.module').then(m => m.IntelyzersModule),
    canActivate: [AuthGuardService]
  },
  {
    path: 'prediction',component:PredictionLogsQueryComponent,
    canActivate: [AuthGuardService]
   
  },
  {
    path: 'user-home',
    loadChildren: () => import('../user/user.module').then(m => m.UserModule),
    // loadChildren: '../user/user.module#UserModule',
    canActivate: [AuthGuardService]
  },
  { path: 'login', component: LoginComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SharedRoutingModule { }
