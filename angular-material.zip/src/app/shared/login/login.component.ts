import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../_services/auth.service';
import { TokenStorageService } from '../../_services/token-storage.service';
import { Router } from '@angular/router';
import { UserService } from '../../_services/user.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  form: FormGroup;
  public loginInvalid: boolean;

  private formSubmitAttempt: boolean;
  private returnUrl: string;
  isLoggedIn = false;
  isLoginFailed = false;
  errorMessage = '';
  // roles: string[] = [];
  userName: string
  role: string
  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private tokenStorage: TokenStorageService,
    private router: Router,
    private userService: UserService) { }

  ngOnInit() {
   
    this.userName = window.sessionStorage.getItem("username")
    this.form = this.fb.group({

      username: ['', [
        Validators.required,
        Validators.minLength(5),
        Validators.pattern("^[a-zA-Z][a-zA-Z0-9\.\_]{3,18}[a-zA-Z0-9]$"),
        Validators.maxLength(20)]
      ],

      password: ['', [Validators.required,
      Validators.maxLength(25),
      Validators.pattern(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%*()_+])/
      )
      ]]

    });
    if (this.tokenStorage.getToken()) {
      this.isLoggedIn = true;
    }
  }
  get f() {
    return this.form.controls;
  }
  onSubmit() {
    const username = this.form.get('username').value;
    const password = this.form.get('password').value;
    this.authService.login(username, password).subscribe(
      data => {
        window.sessionStorage.setItem("username", username);
        this.userName = window.sessionStorage.getItem("username")
        this.tokenStorage.saveToken(data.accessToken);
        this.tokenStorage.saveUserToken(data);
        this.isLoginFailed = false;
        this.isLoggedIn = true;

        if (this.isLoggedIn) {
          this.userService.getUserInfo().subscribe(
            data => {
              window.sessionStorage.setItem("permission",data.roles)
              console.log(data.roles);
              if (data.roles.length > 0) {  // this >= will not be there if there are set of permissions from backent
                setTimeout(() => {
                  this.router.navigate(['home'])
                  setTimeout(() => {
                    this.reloadPage();
                  }, 10)

                }, 1000);
              } else {
                console.log(data.roles);
                setTimeout(() => {
                  this.router.navigate(['/prediction'])
                  setTimeout(() => {
                    this.reloadPage();
                  }, 10)

                }, 1000);
              }
            }
          )
        }
      },
      err => {
        this.errorMessage = err.error.message;
        this.isLoginFailed = true;
      }
    );
  }

  reloadPage() {
    window.location.reload();
  }
  onKeydown(event) {
    if (event.keyCode === 32) {
      return false;
    }
  }
}
