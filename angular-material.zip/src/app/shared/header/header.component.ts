import { Component, OnInit } from '@angular/core';
import { TokenStorageService } from '../../_services/token-storage.service';
import { Router } from '@angular/router';
import { UserService } from '../../_services/user.service';
import { MatPaginator, MatDialog, MatDialogConfig } from '@angular/material';
import { ProfileComponent } from 'src/app/admin/profile/profile.component';
import { ChangePasswordDialogComponent } from 'src/app/admin/change-password-dialog/change-password-dialog.component';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  // title = 'web-ui';
  panelOpenState = false;
  private roles: string[];
  isLoggedIn = false;
  showAdminBoard = false;
  showModeratorBoard = false;
  username: string;
  firstName: String;
  lastName: String;
  email: string;
  userDetails: string;
  isLoginShow: boolean = true;
  routeLink:String
  intelyzersLink:String
  predictionLink:String
  // userdetails:any;
  constructor(private tokenStorageService: TokenStorageService, private router: Router,
    private dialog: MatDialog, private userService: UserService) { }

  ngOnInit() {
    this.isLoggedIn = !!this.tokenStorageService.getToken();
    // console.log(this.tokenStorageService.getToken());
    if (this.router.url.includes("/login")) {
      this.isLoginShow = false
    }
    if (this.isLoggedIn) {
      this.userService.getUserInfo().subscribe(
        data => {
          this.userDetails = JSON.stringify(data);
          this.username=data.login;
          this.firstName = data.first_name;
          this.lastName = data.last_name;
          this.email = data.email;
          if(data.roles.length > 0){
            this.routeLink = "/home"
          }else{
            this.routeLink = "/user-home"
          }
        })

      const user = this.tokenStorageService.getUser();
      this.roles = user.roles;

      // console.log("sanober=="+ this.username);

    }
  }

  onProfile() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "60%";
    let dialogRef = this.dialog.open(ProfileComponent, dialogConfig);
  }
  
changePassword(user:string) {
  const dialogConfig = new MatDialogConfig();
  dialogConfig.disableClose = true;
  dialogConfig.autoFocus = true;
  dialogConfig.width = "40%";
  dialogConfig.data= {login: user};    
  this.dialog.open(ChangePasswordDialogComponent, dialogConfig);
}
  logout() {
    this.tokenStorageService.signOut();
    this.isLoggedIn = false;
    window.location.reload();
       
    this.router.navigate(['/login']);
  }
}
