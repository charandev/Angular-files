import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IntelyzersComponent } from './intelyzers.component';
import { MaterialModule } from '../material.module';
import { IntelyzersRoutingModule } from './intelyzers-routing.module';
import { TicketComponent } from './ticket/ticket.component';
import { TicketDialogComponent } from './ticket-dialog/ticket-dialog.component';
import { UploadTicketComponent } from './upload-ticket/upload-ticket.component';
import { PredictionLogsQueryComponent } from './prediction-logs-query/prediction-logs-query.component';
import { PredictionLogReqDialogComponent } from './prediction-log-req-dialog/prediction-log-req-dialog.component';
@NgModule({
  declarations: [IntelyzersComponent, TicketComponent, TicketDialogComponent,TicketDialogComponent, UploadTicketComponent, PredictionLogsQueryComponent, PredictionLogReqDialogComponent],
  imports: [
    CommonModule,
    MaterialModule,
    IntelyzersRoutingModule
  ],
  entryComponents:[TicketDialogComponent,PredictionLogReqDialogComponent]
})
export class IntelyzersModule { }
