import { Component, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserService } from 'src/app/_services/user.service';
import { MatTableDataSource } from '@angular/material/table';
import { NotificationService } from '../../_services/notification.service';
import swal from 'sweetalert2';
import {MatDatepickerInputEvent} from '@angular/material/datepicker';
import { MatSort } from '@angular/material/sort';
import {  MatDialog, MatDialogConfig } from '@angular/material';
import { PredictionLogReqDialogComponent } from '../prediction-log-req-dialog/prediction-log-req-dialog.component';

@Component({
  selector: 'app-prediction-logs-query',
  templateUrl: './prediction-logs-query.component.html',
  styleUrls: ['./prediction-logs-query.component.css']
})
export class PredictionLogsQueryComponent implements OnInit {
  // @ViewChild(HomeComponent) home:HomeComponent;
  products: any = [];
  groups:string[];
  filterGroups:string;
  pred:any=[];
  listData: MatTableDataSource<any>;



  displayedColumns: string[] = ["group_code","service_name","start_date","end_date","exit_status","duration_ms", "request_id"]
   @ViewChild(MatSort) sort: MatSort
  // @ViewChild(MatPaginator) paginator: MatPaginator
  constructor(private httpClient: HttpClient,private userService: UserService,private notif: NotificationService, private dialog: MatDialog) { }
date:string;
toDate:string;
  ngOnInit() {
    this.userService.getUserInfo().subscribe(userinfo=>{
     
      this.groups=userinfo.groups;
    })
    this.httpClient.get("assets/prediction.json").subscribe(data =>{
      
      this.products = data;
      this.products.fromDate=new Date(new Date().getTime() - (24 * 60 * 60 * 1000));
      this.products.fromDate=this.convert(this.products.fromDate);
      this.products.toDate=new Date();
      this.products.toDate=this.convert(this.products.toDate);
      console.log(this.products.toDate);
      if(this.date){
        this.products.fromDate=this.date;
      }
     if(this.filterGroups){
       this.products.groupCodes=this.filterGroups.split(',');
     }
      this.userService.predictionLogQuery(this.products).subscribe(predict=>{
        console.log(predict);
        let array = predict.predictionLogs.map(item => {
          // this.pred=item.response_param;
          console.log(this.pred);
          // 
          return {
            $key: predict.predictionLogs.indexOf(item),
            ...item
          };
        })
        this.pred=array.response_param;
        this.listData = new MatTableDataSource(array)
        
        this.listData.sort = this.sort
        // this.listData.paginator = this.paginator
        if(array==0)
        {
          //console.log("insode");
          (swal as any).fire("No Prediction log for this request "); 
            // this.home;

        }
       
      },
      
      err => {
        console.log("Failed while fetching", err);
        this.notif.warn("Failed while fetching")

      });

    
    })
    
  }
  applyFilter(filterValue: string) {
    this.listData.filter = filterValue.trim().toLowerCase();
}
    
addEvent(type: string, event: MatDatepickerInputEvent<Date>) {
  console.log(this.convert(event.value));
  this.date=this.convert(event.value);
  this.ngOnInit();
  //this.events.push(`${type}: ${event.value}`);
}

addToDate(type: string, event: MatDatepickerInputEvent<Date>) {
  console.log(this.convert(event.value));
  this.toDate=this.convert(event.value);
  this.ngOnInit();
  //this.events.push(`${type}: ${event.value}`);
}
convert(str) {
  var date = new Date(str),
    mnth = ("0" + (date.getMonth() + 1)).slice(-2),
    day = ("0" + date.getDate()).slice(-2);
  return [date.getFullYear(), mnth, day].join("-");
}

filterByGroup(event){
  this.filterGroups=event;
  this.ngOnInit();
}
onRequestDetails(requestdata,responsedata){
  // this.requestParam=requstdata
  // console.log("==="+ requstdata);
  // console.log("==="+ responsedata);
  const dialogConfig = new MatDialogConfig();
// this.dialogBoxSettings;
   dialogConfig.data= {requestdata,responsedata};  
  this.dialog.open(PredictionLogReqDialogComponent, dialogConfig);

}

}
