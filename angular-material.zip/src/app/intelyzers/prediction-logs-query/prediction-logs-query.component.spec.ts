import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PredictionLogsQueryComponent } from './prediction-logs-query.component';

describe('PredictionLogsQueryComponent', () => {
  let component: PredictionLogsQueryComponent;
  let fixture: ComponentFixture<PredictionLogsQueryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PredictionLogsQueryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PredictionLogsQueryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
