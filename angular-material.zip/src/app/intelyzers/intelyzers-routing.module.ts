import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { IntelyzersComponent } from './intelyzers.component';
import {TicketComponent} from './ticket/ticket.component';
import { PredictionLogsQueryComponent } from './prediction-logs-query/prediction-logs-query.component';
const routes: Routes = [
  { path: '', component: IntelyzersComponent },
  {path: 'prediction', component: PredictionLogsQueryComponent},
  { path: 'ticket', component: TicketComponent }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class IntelyzersRoutingModule { }
