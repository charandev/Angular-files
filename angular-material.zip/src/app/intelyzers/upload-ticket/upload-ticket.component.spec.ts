import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadTicketComponent } from './upload-ticket.component';

describe('UploadTicketComponent', () => {
  let component: UploadTicketComponent;
  let fixture: ComponentFixture<UploadTicketComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UploadTicketComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadTicketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
