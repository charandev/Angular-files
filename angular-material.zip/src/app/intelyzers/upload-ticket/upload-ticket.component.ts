import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upload-ticket',
  templateUrl: './upload-ticket.component.html',
  styleUrls: ['./upload-ticket.component.css']
})
export class UploadTicketComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
