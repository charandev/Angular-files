import { Component, OnInit,Inject } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { ResponseClass } from './response';
import { element } from '@angular/core/src/render3';
import { keyframes } from '@angular/animations';

@Component({
  selector: 'app-prediction-log-req-dialog',
  templateUrl: './prediction-log-req-dialog.component.html',
  styleUrls: ['./prediction-log-req-dialog.component.css']
})
export class PredictionLogReqDialogComponent implements OnInit {
  private res:ResponseClass=new ResponseClass();
  appCatgId: String;
  appName:String;
  appOwnerId: String;
  assigneeId:String;
  assigneeName: String;
  brandId: String;
  createdDate: String;
  criticality: String;
  kw1: String;
  kw2: String;
  kw3: String;
  kw4: String;
  kw5: String;
  resolutionTime: String;
  workItemType: String;
 responsedata:any;
 splitData:String[];
 attribute:string[];
  constructor(public dialogRef: MatDialogRef<PredictionLogReqDialogComponent>, @Inject(MAT_DIALOG_DATA) public data:any) { }

  ngOnInit() {
  
  this.appCatgId=  JSON.parse(this.data.requestdata).appCatgId;
  this.appName=  JSON.parse(this.data.requestdata).appName;
  this.appOwnerId=JSON.parse(this.data.requestdata).appOwnerId;
  this.assigneeId=JSON.parse(this.data.requestdata).assigneeId;
  this.assigneeName=JSON.parse(this.data.requestdata).assigneeName;
  this.brandId=JSON.parse(this.data.requestdata).brandId;
  this.createdDate=JSON.parse(this.data.requestdata).createdDate;
  this.criticality=JSON.parse(this.data.requestdata).criticality;
  this.kw1=JSON.parse(this.data.requestdata).kw1;
  this.kw2=JSON.parse(this.data.requestdata).kw2;
  this.kw3=JSON.parse(this.data.requestdata).kw3;
  this.kw4=JSON.parse(this.data.requestdata).kw4;
  this.kw5=JSON.parse(this.data.requestdata).kw5;
  this.resolutionTime=JSON.parse(this.data.requestdata).resolutionTime;
  this.workItemType=JSON.parse(this.data.requestdata).workItemType;

   
  
  this.responsedata= this.data.responsedata;
  
     console.log(Object.values(JSON.parse(this.responsedata)));
     this.splitData=Object.values(JSON.parse(this.responsedata));
     this.splitData.forEach(element=>{
        this.attribute=element['attribute'];
    console.log(element['attribute']);
 })

  }
  

}
