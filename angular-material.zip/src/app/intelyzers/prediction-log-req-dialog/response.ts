export class ResponseClass{
 
    value: String;
    predicted: String;
    probability: String;
    ticketId: String;
    attribute: String;
    decision:String

}

