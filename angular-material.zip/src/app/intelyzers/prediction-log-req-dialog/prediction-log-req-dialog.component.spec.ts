import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PredictionLogReqDialogComponent } from './prediction-log-req-dialog.component';

describe('PredictioLogReqDialogComponent', () => {
  let component: PredictionLogReqDialogComponent;
  let fixture: ComponentFixture<PredictionLogReqDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PredictionLogReqDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PredictionLogReqDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
