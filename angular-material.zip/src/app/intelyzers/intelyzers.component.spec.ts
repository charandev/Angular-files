import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IntelyzersComponent } from './intelyzers.component';

describe('IntelyzersComponent', () => {
  let component: IntelyzersComponent;
  let fixture: ComponentFixture<IntelyzersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IntelyzersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IntelyzersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
