import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-intelyzers',
  templateUrl: './intelyzers.component.html',
  styleUrls: ['./intelyzers.component.css']
})
export class IntelyzersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
