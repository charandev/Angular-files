import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ticket-dialog',
  templateUrl: './ticket-dialog.component.html',
  styleUrls: ['./ticket-dialog.component.css']
})
export class TicketDialogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
